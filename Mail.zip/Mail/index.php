<html>
	<body>
		<form action="email.php" method="post">
			<input type="text" name="nome">
			<input type="email" name="email">
			<input type="submit">
		</form>
	</body>
</html>